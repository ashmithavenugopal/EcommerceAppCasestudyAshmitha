﻿using EcommerceApplicationCasestudy.Models;
using EcommerceApplicationCasestudy.Repository;
using EcommerceApplicationCasestudy.Service;
using EcommerceApplicationCasestudy.Exceptions;


namespace Testing.nUnitTests
{
    public class ProductIdNotFoundExceptionTest
    {
        [SetUp]
        public void Setup()
        {
        }


        [Test]

        [TestCase(28, ExpectedResult = 0)]
        [TestCase(58, ExpectedResult = 0)]
        public int ProductIdNotFoundExcepTest(int productId)
        {
            OrderProcessorService orderProcessorService = new OrderProcessorService();
            OrderProcessorRepository orderProcessorRepository = new OrderProcessorRepository();


            bool Prodnotfound = orderProcessorRepository.ProductNotFound(productId);
            return Prodnotfound ? 1 : 0;
        }

    }
}
