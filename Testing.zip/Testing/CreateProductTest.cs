﻿using EcommerceApplicationCasestudy.Models;
using EcommerceApplicationCasestudy.Repository;
using EcommerceApplicationCasestudy.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing
{
    public class ProductCreatedTests
    {
        [SetUp]
        public void Setup()
        {
        }



        [Test]
        public void CreateproductserviceTest()
        {
            OrderProcessorService orderProcessorService = new OrderProcessorService();
            OrderProcessorRepository orderProcessorRepository = new OrderProcessorRepository();

            Product product = new Product()
            {
                Name = "comb",
                Price = 200,
                Description = "its just a comb",
                StockQuantity = 10
            };


            bool addProduct = orderProcessorRepository.CreateProduct(product);
            Assert.That(true, Is.EqualTo(addProduct));
        }

    }
}
