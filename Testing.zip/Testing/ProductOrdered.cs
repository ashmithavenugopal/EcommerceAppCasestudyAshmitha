﻿using EcommerceApplicationCasestudy.Models;
using EcommerceApplicationCasestudy.Repository;
using EcommerceApplicationCasestudy.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing
{
    public class ProductOrdered
    {
        [SetUp]
        public void Setup()
        {     //OrderItem orderitem, Product product
        }

        [Test]
        public void OrderproductTest()
        {
            OrderProcessorService orderProcessorService = new OrderProcessorService();
            OrderProcessorRepository orderProcessorRepository = new OrderProcessorRepository();

            Customer customer = new Customer()
            {
                CustomerId = 2
            };

            Order order = new Order()
            {
                ShippingAddress = "Kk nagar"
            };
            Product product = new Product()
            {
                ProductId = 101
            };
            OrderItem orderitem = new OrderItem()
            {
                Quantity = 23 
            };

            bool Productorderedsuccess = orderProcessorService.Placeorderservice(customer,order,orderitem,product);
            Assert.That(true, Is.EqualTo(Productorderedsuccess));






        }
    }
}
